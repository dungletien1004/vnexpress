1. chạy 'npm i' để install module
2. sau khi install node_modules chạy 'npm start' để mở trang web