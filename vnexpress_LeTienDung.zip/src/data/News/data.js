const dataNews = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
];
const dataNewsTopStory = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
];
const dataNewsPodCast = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
];
const dataNewsStreamHome = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: 'Nhà chứng tích Ngô Đình Cẩn hoang phế',
        image: 'https://i1-vnexpress.vnecdn.net/2022/07/26/ndc-6-1658825435.jpg?w=220&h=132&q=100&dpr=1&fit=crop&s=Xn7vl2ODoVPPDaNxqE6pHA',
        description:
            'Di tích quốc gia nhà chứng tích Ngô Đình Cẩn, người được xem là "lãnh chúa miền Trung" những năm 1955-1964, bị bỏ hoang gần 60 năm, cây cỏ mọc um tùm.',

        countComment: 77,
        field: 'Giải trí',
    },
    {
        id: 5,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 6,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 7,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 8,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 9,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 10,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 11,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 12,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
];
const dataNewsKinhDoanh = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
    {
        id: 5,
        link: 'https://vnexpress.net/',
        title: 'FLCHomes lỗ hơn 43 tỷ nửa đầu năm',
        image: 'https://i1-kinhdoanh.vnecdn.net/2022/07/28/94E4901DF5E96F998C6CD2CF56F38D-1551-7382-1658991655.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=9faqsrBv0eS7i41VYOCDRA',
        description:
            'Giá thuê của nhiều căn nhà mặt tiền hiện giảm 30-40% sau khi các đại gia bán lẻ, ẩm thực, thức uống ... ',

        countComment: 77,
        field: 'Kinh doanh',
    },
];
const dataNewsTheThao = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 5,
        link: 'https://vnexpress.net/',
        title: 'Ronaldo vẫn muốn rời Man Utd',
        image: 'https://i1-thethao.vnecdn.net/2022/07/28/ronaldo-reuters-jpeg-165897660-4084-5102-1658976690.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=Y7mFzlLwZPbpfZEoxYSD8w',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
];
const dataNewsGiaiTri = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 5,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        image: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
];
const dataNewsVideo = [
    {
        id: 1,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        video: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 2,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        video: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 3,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        video: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 4,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        video: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        description:
            'Trong cuộc đàm phán ngày 26/7, siêu sao Cristiano Ronaldo một lần nữa đề nghị Man Utd thanh lý hợp đồng để anh tự do ra đi   ',

        countComment: 77,
        field: 'Thể thao',
    },
    {
        id: 5,
        link: 'https://vnexpress.net/',
        title: "Tuyên Huyên: 'Tôi và Cổ Thiên Lạc như huynh đệ'",
        video: 'https://i1-giaitri.vnecdn.net/2022/07/28/tuyen-1658986439-2753-1658986822.jpg?w=380&h=228&q=100&dpr=1&fit=crop&s=LinRv2EAm0E5o_O-mjZVDA',
        field: 'Thể thao',
    },
];
export {
    dataNews,
    dataNewsTopStory,
    dataNewsStreamHome,
    dataNewsKinhDoanh,
    dataNewsTheThao,
    dataNewsGiaiTri,
    dataNewsVideo,
    dataNewsPodCast,
};
