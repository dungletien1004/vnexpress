import Home from '~/pages/Home/Home';
const publishRoutes = [
    {
        path: '/',
        component: Home,
    },
];
const privateRoutes = [];

export { privateRoutes, publishRoutes };
