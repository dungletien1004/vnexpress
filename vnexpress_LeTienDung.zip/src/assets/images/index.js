const images = {
    logo: require('~/assets/images/logo.svg').default,
    eLetter: require('~/assets/images/eLetter.jpg'),
    home: require('~/assets/images/home.png'),
};
export default images;
